# airo-nrf52840-boards
Collection of microcontroller boards developed at IDLab-AIRO (Ghent University, imec), derived from the Arduino Nano 33 BLE, .
