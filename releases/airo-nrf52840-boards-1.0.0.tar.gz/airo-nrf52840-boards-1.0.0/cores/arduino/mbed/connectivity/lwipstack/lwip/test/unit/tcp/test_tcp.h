#ifndef LWIP_HDR_TEST_TCP_H
#define LWIP_HDR_TEST_TCP_H

#include "../lwip_check.h"

Suite *tcp_suite(void);

#endif
