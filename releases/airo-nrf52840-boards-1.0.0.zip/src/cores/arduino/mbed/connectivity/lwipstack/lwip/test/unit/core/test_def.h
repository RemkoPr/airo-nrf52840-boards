#ifndef LWIP_HDR_TEST_DEF_H
#define LWIP_HDR_TEST_DEF_H

#include "../lwip_check.h"

Suite *def_suite(void);

#endif
